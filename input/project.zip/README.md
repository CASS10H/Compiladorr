# TikTok Live Studio — Android

Projeto Android independente em Kotlin, Jetpack Compose e RootEncoder.

## Base recebida
- `TikTok-Live-Studio-Android-v0.3.0.zip`

## Desenvolvimento 0.3.2 — etapa 2: integração do encoder na interface
- RootEncoder 2.8.1 com `GenericStream` como proprietário da fonte Camera2 e do microfone.
- Prévia `SurfaceView` ligada ao mesmo pipeline que codifica e transmite o vídeo.
- Preparação dos codecs H.264/AAC (720x1280, 30 FPS, 2,5 Mbps de vídeo e 128 kbps de áudio).
- Alternância da câmera pelo `Camera2Source.switchCamera()`.
- Silenciamento real do microfone por `MicrophoneSource.mute()` / `unMute()`.
- Ação de iniciar transmissão com endpoint RTMP/RTMPS completo formado a partir do servidor e da chave.
- Ação de encerrar transmissão e callbacks reais de conexão, autenticação e bitrate.
- Cronômetro iniciado somente após callback de conexão bem-sucedida.
- Tratamento visual de falha de preparação e falha de conexão.
- Versão do aplicativo atualizada para 0.3.2 (versionCode 5).

## Dependências relevantes
- AndroidX / Jetpack Compose.
- CameraX permanece no projeto por compatibilidade com a base recebida, mas a prévia de estúdio desta etapa não usa CameraX: ela usa a superfície do RootEncoder para evitar duas APIs disputando a câmera.
- RootEncoder 2.8.1, distribuído via JitPack, para captura Camera2/microfone, codificação MediaCodec e transporte RTMP/RTMPS.

## Compilação
Requer JDK 17, Android SDK 35 e Gradle 8.9. A dependência RootEncoder 2.8.1 é obtida pelo JitPack.
Na raiz do projeto: `gradle :app:assembleDebug`.
APK esperado: `app/build/outputs/apk/debug/app-debug.apk`.

## Estado real das funções nesta etapa
- A tela agora usa o encoder RootEncoder para preparar vídeo/áudio e gerar a prévia.
- O botão de câmera chama a troca de câmera Camera2.
- O botão de microfone silencia/reativa a fonte de áudio real.
- O botão de live chama `startStream()` com endpoint RTMP/RTMPS; os estados de conexão vêm dos callbacks da biblioteca.
- O cronômetro só inicia após `onConnectionSuccess()`.
- Ainda não foi executada compilação Gradle nem teste em aparelho nesta etapa: o ambiente de edição não possui Gradle instalado nem Android SDK configurado.
- O streaming ainda pertence ao ciclo de vida da Activity. O serviço Android em primeiro plano, notificação persistente, captura MediaProjection, reconexão controlada, estatísticas completas e sistema de cenas/overlays permanecem pendentes.
- A tela não deve ser considerada validada para uso em produção até compilar e testar com um servidor RTMP/RTMPS real e dispositivo Android.

## Segurança
- Não coloque chaves no código ou em commits.
- A chave é cifrada com AES-GCM e protegida pelo Android Keystore.
- Prefira RTMPS quando o servidor oferecer suporte.
- O projeto é independente e não possui afiliação com o TikTok.


## Versão 0.3.3 — etapa 3 (serviço em primeiro plano)

### Implementado nesta etapa
- Adicionado `StreamingForegroundService`, serviço Android não exportado.
- Declaração explícita do tipo `camera|microphone` no Manifest.
- Permissões `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_CAMERA` e `FOREGROUND_SERVICE_MICROPHONE`.
- Notificação persistente de transmissão em andamento.
- O app inicia o serviço em primeiro plano antes de solicitar a conexão RTMP e o encerra em falhas, desconexão, encerramento manual e descarte da tela.
- `versionCode` 6 e `versionName` 0.3.3.

### Limitação conhecida — importante
Nesta etapa o serviço mantém o processo em primeiro plano, mas o objeto `RtmpStreamEngine` ainda pertence à tela Compose/Activity. Portanto, isto é uma etapa intermediária: não garante continuidade se a Activity for destruída pelo sistema ou recriada. A próxima refatoração deve transferir a propriedade do encoder para um serviço vinculado (bound service) e fazer a Activity apenas anexar/remover a superfície de prévia.

A captura de tela via MediaProjection ainda não está implementada nesta versão. Ela exige consentimento explícito do usuário, serviço com tipo `mediaProjection` e ciclo de vida próprio. Não há tentativa de contornar as permissões Android.

### Validação
- Manifest XML: validado sintaticamente.
- Estrutura ZIP: validada após empacotamento.
- Compilação Gradle/Android: não executada neste ambiente (Gradle wrapper e Android SDK não estão disponíveis).
- Testes em dispositivo e teste de RTMP: não executados.


## Versão 0.3.4 — etapa 4 (propriedade do encoder no serviço)

### Alterações desta etapa
- `StreamingForegroundService` agora cria e mantém o `RtmpStreamEngine`; a Activity não cria mais uma instância própria do encoder.
- A Activity se conecta ao serviço por `LocalBinder` e encaminha comandos de preparar, iniciar prévia, alternar câmera, silenciar microfone, iniciar e encerrar a transmissão.
- Os callbacks de conexão e bitrate são encaminhados do serviço para a interface.
- O estado conectado e o instante monotônico de conexão ficam no serviço para permitir que a Activity recupere o estado básico ao ser recriada.
- A notificação persistente ganhou ação explícita para encerrar a transmissão e ação para voltar ao aplicativo.
- A permissão de notificações é solicitada no Android 13+ para que o controle persistente fique visível na gaveta de notificações.
- Tráfego cleartext foi habilitado para permitir servidores `rtmp://`; a interface alerta que RTMP sem TLS pode expor a chave e recomenda `rtmps://`.
- O serviço usa `START_NOT_STICKY`: após morte inesperada do processo, o Android não tenta recriar uma sessão sem revalidar permissões e estado.
- `versionCode` 7 e `versionName` 0.3.4.

### Limites ainda existentes
- O serviço passa a ser proprietário do encoder, mas a reanexação da superfície de prévia após destruição/recriação da Activity ainda precisa ser validada em aparelho. A continuidade da codificação/transmissão e a reanexação visual são problemas distintos.
- A captura MediaProjection ainda não está implementada nesta versão. A próxima etapa deve solicitar consentimento pelo sistema, iniciar o serviço com tipo `mediaProjection`, registrar `MediaProjection.Callback`, criar `ScreenSource` e liberar corretamente a projeção.
- Reconexão automática, estatísticas completas de FPS, overlays/cenas editáveis e testes com servidor RTMP real permanecem pendentes.

### Validação desta etapa
- Estrutura do projeto e referências entre Activity/Service revisadas estaticamente.
- Manifest XML validado sintaticamente.
- Integridade do ZIP validada após empacotamento.
- Não foi possível executar `assembleDebug`: este ambiente não possui Android SDK nem Gradle instalado/configurado. A presença de JDK 21, isoladamente, não valida uma compilação Android.
- Não foram realizados testes em dispositivo, ciclo de vida em segundo plano ou transmissão real nesta etapa.


## Versão 0.3.5 — etapa 5 (captura de tela MediaProjection)

### Implementado no código
- Declarada a permissão `FOREGROUND_SERVICE_MEDIA_PROJECTION` e o tipo `mediaProjection` no serviço.
- A Activity solicita autorização por `MediaProjectionManager.createScreenCaptureIntent()` e só encaminha o token ao serviço quando o sistema retorna `RESULT_OK`.
- O serviço promove-se para primeiro plano com o tipo `camera|microphone|mediaProjection` antes de chamar `getMediaProjection()`.
- O `RtmpStreamEngine` troca a fonte de vídeo Camera2 por `ScreenSource` do RootEncoder 2.8.1.
- O modo tela ativa renderização forçada limitada a 15 FPS, como no exemplo oficial do RootEncoder, e desativa essa opção ao voltar à câmera.
- A captura de tela mantém a fonte de áudio `MicrophoneSource`; o microfone continua sendo o áudio transmitido durante o compartilhamento.
- O controle de tela permite iniciar/parar o compartilhamento; ao parar, o motor volta à fonte Camera2 e encerra a projeção.
- Se o Android revogar a projeção (por exemplo, pelo controle de privacidade do sistema), o callback interrompe a live e encerra o compartilhamento por segurança.
- O serviço atualiza a notificação para indicar quando a tela está sendo compartilhada.
- `versionCode` 8 e `versionName` 0.3.5.

### Limitações conhecidas
- A captura de áudio interno do dispositivo e a mistura de áudio interno + microfone ainda não foram implementadas. Nesta versão o compartilhamento de tela transmite o microfone.
- Não foi validado em dispositivo real o comportamento de `ScreenSource`, mudança de fonte durante uma live, áudio, rotação, revogação de MediaProjection ou compatibilidade de fabricantes.
- A prévia ainda precisa de teste específico de reanexação de `SurfaceView` após destruição/recriação da Activity.
- Reconexão automática, métricas completas de FPS, cenas/overlays editáveis e configurações persistentes de resolução/FPS/bitrate continuam pendentes.

### Regras de ciclo de vida
- Cada compartilhamento exige uma nova autorização do Android; o token não é persistido nem reutilizado.
- A chamada `getMediaProjection()` ocorre somente depois da promoção do serviço com o tipo `mediaProjection`.
- O callback de `MediaProjection` é usado para detectar encerramento externo e parar a transmissão.
- A projeção é encerrada ao parar manualmente o compartilhamento, encerrar a live ou destruir o serviço.

### Validação desta etapa
- Manifest XML analisado sintaticamente.
- Chamadas e construtores RootEncoder conferidos na documentação oficial da versão 2.8.1 (`ScreenSource`, `Camera2Source`, `GenericStream`).
- ZIP e integridade dos arquivos serão verificados no empacotamento.
- Compilação Gradle/Android, testes de instrumentação e testes em dispositivo não foram executados neste ambiente (Android SDK e Gradle não estão disponíveis).


## Versão 0.3.6 — etapa 6 (cenas e sobreposições de texto)

### Implementado no código
- Os chips de cena deixaram de ser apenas visuais: `Principal` e `Gameplay` aplicam títulos/subtítulos diferentes ao vídeo.
- A opção `+ Texto` abre um editor de título e subtítulo com limites de caracteres para evitar textos excessivamente longos.
- A sobreposição é desenhada no pipeline OpenGL do RootEncoder com `TextFilterRender` e `GlInterface.addFilter`; portanto, integra a imagem codificada e não é apenas um elemento Compose sobre a prévia.
- O texto pode ser removido sem limpar os demais filtros do pipeline.
- A sobreposição permanece no pipeline quando a fonte de vídeo muda entre câmera e captura de tela.
- `versionCode` 9 e `versionName` 0.3.6.

### Limitações conhecidas
- As cenas são presets de texto sobre a fonte de vídeo atual; ainda não são layouts multicâmera, picture-in-picture ou composição com fontes independentes.
- O texto ainda não é persistido entre reinicializações do app.
- Não há upload/seleção de imagens ou logos nesta etapa.
- A posição e a legibilidade da sobreposição precisam ser verificadas em diferentes resoluções e proporções em aparelho real.

### Validação desta etapa
- Uso de `TextFilterRender`, `TranslateTo.BOTTOM`, `GlInterface.addFilter` e `removeFilter` conferido na documentação/exemplo oficial do RootEncoder 2.8.1.
- Compilação Gradle, teste visual da sobreposição e transmissão real não foram executados: este ambiente não tem Android SDK/Gradle configurados.


## Versão 0.3.7 — etapa 7 (estatísticas e reconexão controlada)

### Implementado no código
- A interface passa a apresentar os campos reais de `StreamingStatsReport` do RootEncoder 2.8.1: total de bytes enviados, bytes por segundo, tamanho da fila de saída, percentual de congestionamento, bitrate suavizado e indicador de throughput.
- O bitrate instantâneo continua vindo do callback `onNewBitrate`.
- Em falhas de conexão, o serviço tenta reconectar pelo `GenericStreamClient.reTry()` do RootEncoder, com até três tentativas controladas pela aplicação e atrasos progressivos de 1, 2 e 4 segundos.
- A interface informa o número da tentativa e volta ao estado conectado quando o callback de sucesso chega.
- Erros de autenticação continuam sendo tratados separadamente e não devem ser confundidos com falhas transitórias de rede.
- A tentativa é cancelada quando a sessão é encerrada e o contador é reiniciado ao iniciar uma nova transmissão.
- `versionCode` 10 e `versionName` 0.3.7.

### Limitações conhecidas
- O relatório `StreamingStatsReport` da versão 2.8.1 fornece throughput, bytes e fila; não fornece FPS. A tela ainda não exibe FPS nem contadores de quadros descartados.
- A estratégia de reconexão está integrada ao cliente da biblioteca, mas precisa de teste com perda real de rede, servidor RTMP/RTMPS e comportamento específico do servidor.
- Não há confirmação visual de recuperação até o callback real `onConnectionSuccess()`.
- Não foi validado o comportamento de reconexão durante captura MediaProjection ou com a Activity recriada.

### Validação desta etapa
- Campos e métodos de `StreamingStatsReport`, `GenericStreamClient.reTry()` e `setReTries()` conferidos na documentação oficial do RootEncoder 2.8.1.
- Compilação Gradle, testes de rede e transmissão em dispositivo Android não foram executados neste ambiente sem Android SDK/Gradle.


## Versão 0.3.8 — etapa 8 (configurações persistentes de codificação)

### Implementado no código
- Criado `VideoConfigStore`, separado das credenciais RTMP, para persistir opções de codificação em `SharedPreferences`.
- Configuração de resolução vertical em 480×854, 720×1280 ou 1080×1920.
- Seleção de 15, 24, 30 ou 60 FPS.
- Bitrate de vídeo configurável entre 500 e 8000 kbps.
- Bitrate de áudio configurável entre 64 e 320 kbps, amostragem de 44100 ou 48000 Hz e opção mono/estéreo.
- A tela carrega as preferências salvas e as entrega ao encoder durante a preparação.
- Ao salvar alterações fora de uma transmissão, o serviço recria o encoder e tenta reanexar a prévia. Durante uma live, a alteração é bloqueada.
- `versionCode` 11 e `versionName` 0.3.8.

### Limitações e validação
- Os limites de configuração são validações do aplicativo; a aceitação efetiva de cada combinação depende dos codecs e do aparelho Android.
- A prévia é recriada ao aplicar as opções; a continuidade visual da superfície precisa ser confirmada em aparelho.
- Integridade do ZIP e análise estática são verificadas no empacotamento. Compilação Gradle, geração de APK, teste de codecs e transmissão real não foram executados neste ambiente.


## Hotfix 0.3.8.1 — compatibilidade Kotlin

Esta revisão corrige a incompatibilidade identificada no log do GitHub Actions: o projeto usava Kotlin Gradle Plugin 2.0.21, enquanto as bibliotecas RootEncoder 2.8.1 foram publicadas com metadados Kotlin 2.2.0 e o cache do build continha kotlin-stdlib 2.3.21. Os plugins `org.jetbrains.kotlin.android` e `org.jetbrains.kotlin.plugin.compose` foram alinhados para 2.3.21. O AGP foi mantido em 8.7.3 e o código do app foi incrementado para 12.

A exceção `source must not be null` apontada em `CameraPreview.kt` ocorreu durante a análise FIR e junto dos erros de metadados incompatíveis; ela não comprova, isoladamente, defeito na linha indicada. Reexecutar o build é necessário para confirmar se desaparece após o alinhamento do compilador.

**Validação desta revisão:** arquivos Gradle conferidos e ZIP verificado. Não foi possível executar `gradle assembleDebug` neste ambiente; portanto, esta hotfix ainda precisa ser validada no GitHub Actions.
