package com.cass10h.tiktoklivestudio

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Guarda a chave de transmissão cifrada com AES-GCM e uma chave protegida
 * pelo Android Keystore. A chave nunca deve ser incluída no repositório.
 */
class SecureRtmpStore(context: Context) {
    private val prefs = context.getSharedPreferences("rtmp_secure_config", Context.MODE_PRIVATE)
    private val alias = "tiktok_live_studio_rtmp_key"

    fun save(server: String, streamKey: String) {
        require(server.startsWith("rtmp://", ignoreCase = true) || server.startsWith("rtmps://", ignoreCase = true)) {
            "O endereço precisa começar com rtmp:// ou rtmps://."
        }
        require(streamKey.isNotBlank()) { "A chave de transmissão não pode ficar vazia." }
        val encrypted = encrypt(streamKey.trim())
        prefs.edit()
            .putString("server", server.trim())
            .putString("key_iv", Base64.encodeToString(encrypted.first, Base64.NO_WRAP))
            .putString("key_data", Base64.encodeToString(encrypted.second, Base64.NO_WRAP))
            .apply()
    }

    fun loadServer(): String = prefs.getString("server", "") ?: ""

    fun hasKey(): Boolean =
        !prefs.getString("key_data", null).isNullOrBlank() &&
        !prefs.getString("key_iv", null).isNullOrBlank()

    fun clear() {
        prefs.edit().clear().apply()
        runCatching {
            KeyStore.getInstance("AndroidKeyStore").apply { load(null) }.deleteEntry(alias)
        }
    }

    private fun encrypt(value: String): Pair<ByteArray, ByteArray> {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateSecretKey())
        return cipher.iv to cipher.doFinal(value.toByteArray(Charsets.UTF_8))
    }

    @Suppress("unused")
    fun readKeyForUpdate(): String {
        val iv = Base64.decode(prefs.getString("key_iv", "") ?: "", Base64.NO_WRAP)
        val data = Base64.decode(prefs.getString("key_data", "") ?: "", Base64.NO_WRAP)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateSecretKey(), GCMParameterSpec(128, iv))
        return cipher.doFinal(data).toString(Charsets.UTF_8)
    }

    private fun getOrCreateSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = keyStore.getKey(alias, null) as? SecretKey
        if (existing != null) return existing

        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                alias,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }
}
