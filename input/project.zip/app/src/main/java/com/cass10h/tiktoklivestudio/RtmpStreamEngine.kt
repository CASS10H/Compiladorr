package com.cass10h.tiktoklivestudio

import android.content.Context
import android.graphics.Color
import android.media.projection.MediaProjection
import android.view.SurfaceView
import com.pedro.common.ConnectChecker
import com.pedro.common.StreamingStatsReport
import com.pedro.encoder.input.sources.audio.MicrophoneSource
import com.pedro.encoder.input.sources.video.Camera2Source
import com.pedro.encoder.input.sources.video.ScreenSource
import com.pedro.encoder.input.gl.render.filters.`object`.TextFilterRender
import com.pedro.encoder.utils.gl.TranslateTo
import com.pedro.library.generic.GenericStream

/**
 * Proprietário do encoder e das fontes Camera2/Microphone do RootEncoder.
 * A prévia exibida pela UI é a mesma superfície renderizada pelo encoder.
 */
class RtmpStreamEngine(
    context: Context,
    private val listener: Listener
) : ConnectChecker {

    interface Listener {
        fun onConnecting()
        fun onConnected()
        fun onConnectionFailed(reason: String)
        fun onDisconnected()
        fun onAuthenticationError()
        fun onAuthenticationSuccess()
        fun onNewBitrate(bitrate: Long)
        fun onStats(report: StreamingStatsReport?)
        fun onScreenProjectionStopped()
    }

    data class VideoConfig(
        val width: Int = 720,
        val height: Int = 1280,
        val videoBitrate: Int = 2_500_000,
        val fps: Int = 30,
        val audioBitrate: Int = 128_000,
        val sampleRate: Int = 44_100,
        val stereo: Boolean = true
    )

    private val appContext = context.applicationContext
    private val stream = GenericStream(appContext, this)
    private var prepared = false
    private var activeProjection: MediaProjection? = null
    private var screenCaptureActive = false
    private var releasingProjection = false
    private var preferredCameraId: String? = null
    private var sceneOverlay: TextFilterRender? = null

    val isScreenCaptureActive: Boolean get() = screenCaptureActive

    val isStreaming: Boolean get() = stream.isStreaming
    val isPreviewing: Boolean get() = stream.isOnPreview
    val isPrepared: Boolean get() = prepared

    fun prepare(config: VideoConfig = VideoConfig()): Boolean {
        if (isStreaming || isPreviewing) return false
        prepared = runCatching {
            stream.prepareVideo(
                config.width,
                config.height,
                config.videoBitrate,
                config.fps
            ) && stream.prepareAudio(
                config.sampleRate,
                config.stereo,
                config.audioBitrate,
                true,
                true
            )
        }.getOrDefault(false)
        return prepared
    }

    fun startPreview(surfaceView: SurfaceView) {
        check(prepared) { "O encoder ainda não foi preparado." }
        if (!stream.isOnPreview) stream.startPreview(surfaceView)
    }

    fun switchCamera(): Result<Unit> = runCatching {
        check(prepared) { "Prepare o encoder antes de trocar a câmera." }
        check(!screenCaptureActive) { "Encerre o compartilhamento de tela antes de trocar a câmera." }
        val source = stream.videoSource as? Camera2Source
            ?: error("A fonte de vídeo atual não é Camera2.")
        source.switchCamera()
        preferredCameraId = source.getCurrentCameraId()
    }

    private fun createPreferredCameraSource(): Camera2Source {
        return Camera2Source(appContext).also { source ->
            preferredCameraId?.let { cameraId ->
                runCatching { source.openCameraId(cameraId) }
            }
        }
    }

    /**
     * Substitui a fonte de câmera por ScreenSource usando a autorização explícita
     * recebida do sistema. O serviço precisa já estar em primeiro plano com o
     * tipo mediaProjection antes que este método seja chamado.
     */
    fun startScreenCapture(projection: MediaProjection): Result<Unit> = runCatching {
        check(prepared) { "Prepare o encoder antes de compartilhar a tela." }
        check(!screenCaptureActive) { "A captura de tela já está ativa." }

        val projectionCallback = object : MediaProjection.Callback() {
            override fun onStop() {
                // Ignora callbacks tardios de projeções que o próprio app já encerrou.
                if (activeProjection === projection && !releasingProjection) {
                    activeProjection = null
                    screenCaptureActive = false
                    listener.onScreenProjectionStopped()
                }
            }
        }

        (stream.videoSource as? Camera2Source)?.let { currentCamera ->
            preferredCameraId = runCatching { currentCamera.getCurrentCameraId() }.getOrNull()
        }

        // A projeção pode produzir quadros somente quando o conteúdo muda.
        // Forçamos renderização limitada a 15 FPS, conforme o exemplo oficial do RootEncoder.
        try {
            stream.getGlInterface().setForceRender(true, 15)
            // ScreenSource registra o callback antes de criar seu VirtualDisplay.
            stream.changeVideoSource(
                ScreenSource(appContext, projection, projectionCallback)
            )
            activeProjection = projection
            screenCaptureActive = true
        } catch (error: Throwable) {
            runCatching { stream.getGlInterface().setForceRender(false) }
            throw error
        }
    }

    /** Retorna à câmera e encerra a autorização de captura atual. */
    fun stopScreenCapture(): Result<Unit> = runCatching {
        if (!screenCaptureActive) return@runCatching
        val projection = activeProjection
        releasingProjection = true
        try {
            stream.changeVideoSource(createPreferredCameraSource())
            stream.getGlInterface().setForceRender(false)
            activeProjection = null
            screenCaptureActive = false
            projection?.stop()
        } finally {
            releasingProjection = false
        }
    }

    /** Chamado quando o Android revoga a projeção fora do fluxo normal do app. */
    fun handleProjectionStoppedBySystem() {
        activeProjection = null
        screenCaptureActive = false
        if (prepared) {
            runCatching {
                stream.changeVideoSource(createPreferredCameraSource())
                stream.getGlInterface().setForceRender(false)
            }
        }
    }

    /** Adiciona uma legenda gráfica à imagem codificada (prévia e transmissão). */
    fun setSceneOverlay(title: String, subtitle: String): Result<Unit> = runCatching {
        check(prepared) { "Prepare o encoder antes de configurar a cena." }
        val content = listOf(title.trim(), subtitle.trim())
            .filter { it.isNotEmpty() }
            .joinToString("\n")
        val gl = stream.getGlInterface()
        sceneOverlay?.let { runCatching { gl.removeFilter(it) } }
        sceneOverlay = null
        if (content.isNotEmpty()) {
            val overlay = TextFilterRender().apply {
                setText(content, 22f, Color.WHITE)
                setScale(90f, 22f)
                setPosition(TranslateTo.BOTTOM)
            }
            gl.addFilter(overlay)
            sceneOverlay = overlay
        }
    }

    fun clearSceneOverlay(): Result<Unit> = runCatching {
        sceneOverlay?.let { stream.getGlInterface().removeFilter(it) }
        sceneOverlay = null
    }

    fun setMicrophoneMuted(muted: Boolean): Result<Unit> = runCatching {
        check(prepared) { "Prepare o encoder antes de controlar o microfone." }
        val source = stream.audioSource as? MicrophoneSource
            ?: error("A fonte de áudio atual não é o microfone.")
        if (muted) source.mute() else source.unMute()
    }

    /** Recebe uma URL completa: rtmp(s)://host/app/stream-key. */
    fun start(endpoint: String): Result<Unit> = runCatching {
        check(prepared) { "O encoder não está preparado." }
        check(!isStreaming) { "Já existe uma transmissão em andamento." }
        val normalized = endpoint.trim()
        require(
            normalized.startsWith("rtmp://", true) ||
                normalized.startsWith("rtmps://", true)
        ) { "Use um endereço RTMP ou RTMPS válido." }
        require(normalized.substringAfter("://").contains('/')) {
            "Informe o caminho da aplicação e a chave de transmissão junto ao servidor."
        }
        // RootEncoder mantém uma política interna limitada de novas tentativas.
        stream.getStreamClient().setReTries(3)
        stream.startStream(normalized)
    }

    /** Solicita uma nova tentativa usando o cliente RTMP do RootEncoder. */
    fun retryConnection(delayMs: Long, reason: String): Boolean {
        if (!stream.isStreaming) return false
        return runCatching {
            stream.getStreamClient().reTry(delayMs, reason)
        }.getOrDefault(false)
    }

    fun stop() {
        if (stream.isStreaming) stream.stopStream()
    }

    fun release() {
        releasingProjection = true
        runCatching { sceneOverlay?.let { stream.getGlInterface().removeFilter(it) } }
        sceneOverlay = null
        runCatching { stream.release() }
        runCatching { activeProjection?.stop() }
        activeProjection = null
        screenCaptureActive = false
        releasingProjection = false
        prepared = false
    }

    override fun onConnectionStarted(url: String) = listener.onConnecting()
    override fun onConnectionSuccess() = listener.onConnected()
    override fun onConnectionFailed(reason: String) = listener.onConnectionFailed(reason)
    override fun onDisconnect() = listener.onDisconnected()
    override fun onAuthError() = listener.onAuthenticationError()
    override fun onAuthSuccess() = listener.onAuthenticationSuccess()
    override fun onNewBitrate(bitrate: Long) = listener.onNewBitrate(bitrate)
    override fun onStreamingStats(report: StreamingStatsReport?) = listener.onStats(report)
}
