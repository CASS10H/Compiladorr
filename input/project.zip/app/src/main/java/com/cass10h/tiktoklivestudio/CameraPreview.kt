package com.cass10h.tiktoklivestudio

import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner

/**
 * Prévia CameraX. A vinculação ocorre somente quando a câmera, o lifecycle
 * owner ou a PreviewView mudam; recomposições normais não rebindeiam a câmera.
 */
@Composable
fun CameraPreview(
    lensFacing: Int,
    modifier: Modifier = Modifier,
    onError: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val cameraProviderFuture = remember(context) {
        ProcessCameraProvider.getInstance(context.applicationContext)
    }
    var previewView by remember { mutableStateOf<PreviewView?>(null) }

    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            PreviewView(ctx).apply {
                scaleType = PreviewView.ScaleType.FILL_CENTER
                implementationMode = PreviewView.ImplementationMode.COMPATIBLE
                previewView = this
            }
        },
        update = { view ->
            if (previewView !== view) previewView = view
        }
    )

    DisposableEffect(previewView, lifecycleOwner, lensFacing, cameraProviderFuture) {
        val view = previewView
        if (view == null) {
            onDispose { }
        } else {
            val executor = ContextCompat.getMainExecutor(context)
            var boundPreview: Preview? = null
            var provider: ProcessCameraProvider? = null
            var disposed = false
            try {
                cameraProviderFuture.addListener({
                    if (disposed) return@addListener
                    try {
                        val cameraProvider = cameraProviderFuture.get()
                        val preview = Preview.Builder().build().also {
                            it.setSurfaceProvider(view.surfaceProvider)
                        }
                        val selector = CameraSelector.Builder()
                            .requireLensFacing(lensFacing)
                            .build()
                        cameraProvider.unbindAll()
                        cameraProvider.bindToLifecycle(lifecycleOwner, selector, preview)
                        provider = cameraProvider
                        boundPreview = preview
                    } catch (error: Exception) {
                        onError(error.message ?: "Não foi possível iniciar a câmera.")
                    }
                }, executor)
            } catch (error: Exception) {
                onError(error.message ?: "Falha ao preparar a câmera.")
            }

            onDispose {
                disposed = true
                val preview = boundPreview
                val cameraProvider = provider
                if (preview != null && cameraProvider != null) {
                    runCatching { cameraProvider.unbind(preview) }
                }
            }
        }
    }
}
