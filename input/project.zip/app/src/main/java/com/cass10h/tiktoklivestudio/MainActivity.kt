package com.cass10h.tiktoklivestudio

import android.Manifest
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.content.Intent
import android.content.ComponentName
import android.content.ServiceConnection
import android.os.IBinder
import android.os.Bundle
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.SurfaceView
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay

private val StudioBg = Color(0xFF121212)
private val StudioPanel = Color(0xFF202020)
private val TikTokPink = Color(0xFFFE2C55)
private val TikTokCyan = Color(0xFF25F4EE)

private enum class LiveState { IDLE, PREPARING, READY, CONNECTING, LIVE, RECONNECTING, ERROR }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(18, 18, 18)
        window.navigationBarColor = android.graphics.Color.rgb(18, 18, 18)
        setContent { StudioScreen() }
    }
}

@Composable
private fun StudioScreen() {
    val context = LocalContext.current
    val secureStore = remember { SecureRtmpStore(context) }
    val videoConfigStore = remember { VideoConfigStore(context) }
    var videoConfig by remember { mutableStateOf(videoConfigStore.load()) }
    var showVideoConfigDialog by remember { mutableStateOf(false) }
    var configWidth by remember { mutableStateOf(videoConfig.width.toString()) }
    var configHeight by remember { mutableStateOf(videoConfig.height.toString()) }
    var configFps by remember { mutableStateOf(videoConfig.fps.toString()) }
    var configVideoKbps by remember { mutableStateOf((videoConfig.videoBitrate / 1000).toString()) }
    var configAudioKbps by remember { mutableStateOf((videoConfig.audioBitrate / 1000).toString()) }
    var configSampleRate by remember { mutableStateOf(videoConfig.sampleRate.toString()) }
    var configStereo by remember { mutableStateOf(videoConfig.stereo) }
    var videoConfigError by remember { mutableStateOf<String?>(null) }
    val mainHandler = remember { Handler(Looper.getMainLooper()) }

    var cameraGranted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    var audioGranted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    var micMuted by remember { mutableStateOf(false) }
    var screenCaptureActive by remember { mutableStateOf(false) }
    var showRtmpDialog by remember { mutableStateOf(false) }
    var showOverlayDialog by remember { mutableStateOf(false) }
    var overlayTitle by remember { mutableStateOf("AO VIVO") }
    var overlaySubtitle by remember { mutableStateOf("Bem-vindos à live!") }
    var selectedScene by remember { mutableStateOf("Sem texto") }
    var serverUrl by remember { mutableStateOf(secureStore.loadServer()) }
    var streamKey by remember { mutableStateOf("") }
    var configSaved by remember { mutableStateOf(secureStore.hasKey() && secureStore.loadServer().isNotBlank()) }
    var validationError by remember { mutableStateOf<String?>(null) }
    var liveState by remember { mutableStateOf(LiveState.IDLE) }
    var statusMessage by remember { mutableStateOf("Conceda as permissões para preparar câmera e microfone.") }
    var bitrate by remember { mutableLongStateOf(0L) }
    var statsReport by remember { mutableStateOf<com.pedro.common.StreamingStatsReport?>(null) }
    var reconnectMessage by remember { mutableStateOf<String?>(null) }
    var startedAt by remember { mutableLongStateOf(0L) }
    var elapsedSeconds by remember { mutableLongStateOf(0L) }
    var surfaceView by remember { mutableStateOf<SurfaceView?>(null) }

    var streamService by remember { mutableStateOf<StreamingForegroundService?>(null) }

    val sessionListener = remember {
        object : StreamingForegroundService.SessionListener {
            override fun onConnecting() = mainHandler.post {
                liveState = LiveState.CONNECTING
                statusMessage = "Conectando ao servidor RTMP…"
            }.let { }

            override fun onConnected() = mainHandler.post {
                liveState = LiveState.LIVE
                startedAt = streamService?.connectedAtElapsedRealtime ?: SystemClock.elapsedRealtime()
                reconnectMessage = null
                statusMessage = "Transmissão conectada e enviando mídia."
            }.let { }

            override fun onConnectionFailed(reason: String) = mainHandler.post {
                liveState = LiveState.ERROR
                reconnectMessage = null
                statsReport = null
                statusMessage = "Falha na conexão após as tentativas: $reason"
            }.let { }

            override fun onDisconnected() = mainHandler.post {
                if (liveState == LiveState.LIVE || liveState == LiveState.CONNECTING) {
                    liveState = LiveState.READY
                    reconnectMessage = null
                    statsReport = null
                    statusMessage = "Transmissão desconectada."
                }
            }.let { }

            override fun onAuthenticationError() = mainHandler.post {
                liveState = LiveState.ERROR
                statsReport = null
                statusMessage = "O servidor recusou a autenticação. Confira a chave."
            }.let { }

            override fun onAuthenticationSuccess() = mainHandler.post {
                statusMessage = "Autenticação aceita pelo servidor."
            }.let { }

            override fun onNewBitrate(bitrateValue: Long) = mainHandler.post {
                bitrate = bitrateValue
            }.let { }

            override fun onStats(report: com.pedro.common.StreamingStatsReport?) = mainHandler.post {
                statsReport = report
            }.let { }

            override fun onReconnecting(attempt: Int, maxAttempts: Int, reason: String) = mainHandler.post {
                liveState = LiveState.CONNECTING
                reconnectMessage = "Reconectando ($attempt/$maxAttempts)…"
                statusMessage = "Conexão instável. Tentando novamente: $reason"
            }.let { }

            override fun onScreenCaptureStopped(wasStreaming: Boolean) {
                mainHandler.post {
                    screenCaptureActive = false
                    liveState = if (wasStreaming) LiveState.ERROR else LiveState.READY
                    statusMessage = if (wasStreaming) {
                        "O Android encerrou a captura de tela; a transmissão foi interrompida por segurança."
                    } else {
                        "O Android encerrou a captura de tela. O compartilhamento foi finalizado."
                    }
                    startedAt = 0L
                }
            }
        }
    }

    val serviceConnection = remember(context) {
        object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                val localBinder = binder as? StreamingForegroundService.LocalBinder ?: return
                streamService = localBinder.getService()
                screenCaptureActive = localBinder.getService().isScreenCaptureActive
            }

            override fun onServiceDisconnected(name: ComponentName?) {
                streamService = null
            }
        }
    }

    DisposableEffect(context, serviceConnection) {
        val bound = context.bindService(
            Intent(context, StreamingForegroundService::class.java),
            serviceConnection,
            android.content.Context.BIND_AUTO_CREATE
        )
        onDispose {
            streamService?.setSessionListener(null)
            if (bound) runCatching { context.unbindService(serviceConnection) }
        }
    }

    DisposableEffect(streamService, sessionListener) {
        streamService?.setSessionListener(sessionListener)
        if (streamService?.isConnected == true) {
            liveState = LiveState.LIVE
            bitrate = streamService?.bitrate ?: 0L
            statusMessage = "Sessão de transmissão mantida pelo serviço em primeiro plano."
            startedAt = streamService?.connectedAtElapsedRealtime ?: SystemClock.elapsedRealtime()
            screenCaptureActive = streamService?.isScreenCaptureActive == true
        } else if (streamService?.isStreaming == true) {
            liveState = LiveState.CONNECTING
            statusMessage = "Reconectando à sessão de transmissão mantida pelo serviço…"
        }
        onDispose { streamService?.setSessionListener(null) }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        cameraGranted = result[Manifest.permission.CAMERA] == true ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        audioGranted = result[Manifest.permission.RECORD_AUDIO] == true ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    }

    val screenCaptureLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        val service = streamService
        if (result.resultCode == android.app.Activity.RESULT_OK && data != null) {
            if (service == null || !service.isPrepared) {
                statusMessage = "O serviço de transmissão ainda não está preparado para capturar a tela."
            } else {
                try {
                    ContextCompat.startForegroundService(
                        context,
                        Intent(context, StreamingForegroundService::class.java).apply {
                            action = StreamingForegroundService.ACTION_START_SCREEN
                        }
                    )
                    service.startScreenCapture(result.resultCode, data)
                        .onSuccess {
                            screenCaptureActive = true
                            statusMessage = "Compartilhando a tela com captura do microfone. O áudio interno ainda não está habilitado."
                        }
                        .onFailure {
                            screenCaptureActive = false
                            statusMessage = it.message ?: "Não foi possível iniciar a captura de tela."
                        }
                } catch (error: Exception) {
                    screenCaptureActive = false
                    statusMessage = "Falha ao iniciar o serviço de captura: ${error.message}"
                }
            }
        } else {
            statusMessage = "A captura de tela foi cancelada. Nenhuma tela está sendo compartilhada."
        }
    }

    val requestRequiredPermissions = {
        val missing = mutableListOf<String>()
        if (!cameraGranted) missing += Manifest.permission.CAMERA
        if (!audioGranted) missing += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            missing += Manifest.permission.POST_NOTIFICATIONS
        }
        if (missing.isNotEmpty()) permissionLauncher.launch(missing.toTypedArray())
    }

    LaunchedEffect(Unit) { requestRequiredPermissions() }

    LaunchedEffect(cameraGranted, audioGranted, surfaceView, streamService) {
        val view = surfaceView
        val service = streamService
        if (cameraGranted && audioGranted && view != null && service != null && !service.isPrepared) {
            liveState = LiveState.PREPARING
            statusMessage = "Preparando encoder de vídeo e áudio no serviço…"
            val prepared = runCatching { service.prepare(videoConfig) }.getOrDefault(false)
            if (prepared) {
                runCatching { service.startPreview(view) }
                    .onSuccess {
                        if (!service.isStreaming) liveState = LiveState.READY
                        statusMessage = "Câmera e microfone preparados pelo serviço de transmissão."
                    }
                    .onFailure {
                        liveState = LiveState.ERROR
                        statusMessage = "Falha ao iniciar prévia: ${it.message}"
                    }
            } else {
                liveState = LiveState.ERROR
                statusMessage = "O dispositivo não conseguiu preparar os codecs H.264/AAC nesta configuração."
            }
        } else if (cameraGranted && audioGranted && service == null) {
            statusMessage = "Conectando ao serviço de transmissão…"
        }
    }

    LaunchedEffect(liveState, startedAt) {
        while (liveState == LiveState.LIVE && startedAt > 0L) {
            elapsedSeconds = ((SystemClock.elapsedRealtime() - startedAt) / 1000L).coerceAtLeast(0L)
            delay(1_000)
        }
        if (liveState != LiveState.LIVE) elapsedSeconds = 0L
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = TikTokPink, secondary = TikTokCyan, background = StudioBg, surface = StudioPanel
    )) {
        Column(
            modifier = Modifier.fillMaxSize().background(StudioBg).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("LIVE STUDIO", color = TikTokCyan, style = MaterialTheme.typography.labelLarge)
                    Text("Central de transmissão", style = MaterialTheme.typography.titleLarge, color = Color.White)
                }
                Surface(
                    color = if (liveState == LiveState.LIVE) Color(0xFF7A1028) else Color(0xFF333333),
                    shape = RoundedCornerShape(30.dp)
                ) {
                    Text(
                        if (liveState == LiveState.LIVE) "● AO VIVO" else "● ${liveState.name}",
                        Modifier.padding(horizontal = 12.dp, vertical = 8.dp), color = Color.White
                    )
                }
            }

            Box(
                Modifier.fillMaxWidth().weight(1f).background(Color.Black, RoundedCornerShape(18.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (cameraGranted && audioGranted) {
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { ctx -> SurfaceView(ctx).also { surfaceView = it } },
                        update = { if (surfaceView !== it) surfaceView = it }
                    )
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Permissões de câmera e microfone necessárias", color = Color.White)
                        Button(onClick = { requestRequiredPermissions() }) { Text("Conceder permissões") }
                    }
                }
                Surface(
                    modifier = Modifier.align(Alignment.TopStart).padding(10.dp),
                    color = Color(0x99000000), shape = RoundedCornerShape(8.dp)
                ) {
                    Text(if (screenCaptureActive) "PRÉVIA DO ENCODER • TELA" else "PRÉVIA DO ENCODER • 9:16", Modifier.padding(horizontal = 10.dp, vertical = 6.dp), color = Color.White)
                }
                Surface(
                    modifier = Modifier.align(Alignment.BottomStart).padding(10.dp),
                    color = Color(0x99000000), shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        if (audioGranted && !micMuted) "MICROFONE ATIVO" else "MICROFONE MUDO",
                        Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        color = if (audioGranted && !micMuted) TikTokCyan else Color.LightGray
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SceneChip("Principal", selectedScene == "Principal") {
                    selectedScene = "Principal"
                    overlayTitle = "AO VIVO"
                    overlaySubtitle = "Bem-vindos à live!"
                    streamService?.setSceneOverlay(overlayTitle, overlaySubtitle)
                        ?.onFailure { statusMessage = it.message ?: "Não foi possível aplicar a cena." }
                }
                SceneChip("Gameplay", selectedScene == "Gameplay") {
                    selectedScene = "Gameplay"
                    overlayTitle = "GAMEPLAY"
                    overlaySubtitle = "Acompanhe a partida"
                    streamService?.setSceneOverlay(overlayTitle, overlaySubtitle)
                        ?.onFailure { statusMessage = it.message ?: "Não foi possível aplicar a cena." }
                }
                SceneChip("+ Texto", false) { showOverlayDialog = true }
            }

            Row(
                modifier = Modifier.fillMaxWidth().background(StudioPanel, RoundedCornerShape(16.dp)).padding(8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                StudioAction("Mic", if (micMuted) "Mudo" else "Ligado") {
                    val nextMuted = !micMuted
                    val service = streamService
                    if (service == null) {
                        statusMessage = "O serviço de transmissão ainda não está conectado."
                    } else {
                        service.setMicrophoneMuted(nextMuted)
                            .onSuccess { micMuted = nextMuted }
                            .onFailure { statusMessage = it.message ?: "Não foi possível alterar o microfone." }
                    }
                }
                StudioAction("Câmera", "Trocar") {
                    streamService?.switchCamera()?.onFailure {
                        statusMessage = it.message ?: "Não foi possível trocar a câmera."
                    } ?: run { statusMessage = "O serviço de transmissão ainda não está conectado." }
                }
                StudioAction("RTMP", "Configurar") { showRtmpDialog = true }
                StudioAction("Vídeo", "${videoConfig.width}×${videoConfig.height}") {
                    configWidth = videoConfig.width.toString(); configHeight = videoConfig.height.toString()
                    configFps = videoConfig.fps.toString(); configVideoKbps = (videoConfig.videoBitrate / 1000).toString()
                    configAudioKbps = (videoConfig.audioBitrate / 1000).toString(); configSampleRate = videoConfig.sampleRate.toString()
                    configStereo = videoConfig.stereo; videoConfigError = null; showVideoConfigDialog = true
                }
                StudioAction("Tela", if (screenCaptureActive) "Parar" else "Compartilhar") {
                    if (screenCaptureActive) {
                        streamService?.stopScreenCapture()
                            ?.onSuccess {
                                screenCaptureActive = false
                                statusMessage = "Captura de tela encerrada. A câmera voltou a ser a fonte de vídeo."
                            }
                            ?.onFailure {
                                statusMessage = it.message ?: "Não foi possível encerrar a captura de tela."
                            }
                            ?: run { statusMessage = "O serviço de transmissão não está disponível." }
                    } else if (!cameraGranted || !audioGranted) {
                        requestRequiredPermissions()
                    } else if (streamService?.isPrepared != true) {
                        statusMessage = "Aguarde a preparação da câmera e do microfone."
                    } else {
                        val manager = context.getSystemService(android.content.Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                        screenCaptureLauncher.launch(manager.createScreenCaptureIntent())
                    }
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${formatDuration(elapsedSeconds)}", color = Color.White)
                Text("${if (bitrate > 0) "${bitrate / 1000} kbps" else "— kbps"}", color = TikTokCyan)
            }
            statsReport?.let { stats ->
                Column(
                    Modifier.fillMaxWidth().background(StudioPanel, RoundedCornerShape(12.dp)).padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Enviados: ${stats.totalBytesOut / 1_000_000} MB", color = Color.White, style = MaterialTheme.typography.labelSmall)
                        Text("Fila: ${stats.queueBytesOut / 1024} KB", color = Color.White, style = MaterialTheme.typography.labelSmall)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Saída: ${stats.bytesOutPerSecond / 1024} KB/s", color = Color.White, style = MaterialTheme.typography.labelSmall)
                        Text("Congestionamento: ${stats.queueCongestionPercent.toInt()}%", color = if (stats.queueCongestionPercent >= 70f) Color(0xFFFFC857) else TikTokCyan, style = MaterialTheme.typography.labelSmall)
                    }
                    Text("Taxa suavizada: ${stats.smoothedBitrate / 1000} kbps • ${stats.throughput}", color = Color.LightGray, style = MaterialTheme.typography.labelSmall)
                }
            }
            reconnectMessage?.let { Text(it, color = Color(0xFFFFC857), style = MaterialTheme.typography.labelSmall) }

            Button(
                onClick = {
                    if (liveState == LiveState.LIVE || liveState == LiveState.CONNECTING) {
                        streamService?.stopStreaming()
                        statsReport = null
                        reconnectMessage = null
                        liveState = LiveState.READY
                        startedAt = 0L
                        statusMessage = "Solicitado encerramento da transmissão."
                    } else if (!configSaved) {
                        showRtmpDialog = true
                    } else {
                        val key = runCatching { secureStore.readKeyForUpdate() }.getOrNull()
                        if (key.isNullOrBlank()) {
                            statusMessage = "A chave salva não pôde ser lida. Configure novamente."
                            showRtmpDialog = true
                        } else {
                            val endpoint = "${serverUrl.trim().trimEnd('/')}/${key.trim().trimStart('/')}"
                            val service = streamService
                            if (service == null || !service.isPrepared) {
                                statusMessage = "A câmera e o microfone ainda estão sendo preparados."
                                return@Button
                            }
                            try {
                                ContextCompat.startForegroundService(
                                    context,
                                    Intent(context, StreamingForegroundService::class.java).apply {
                                        action = StreamingForegroundService.ACTION_START
                                    }
                                )
                            } catch (error: Exception) {
                                statusMessage = "Não foi possível iniciar o serviço em primeiro plano: ${error.message}"
                                liveState = LiveState.ERROR
                                return@Button
                            }
                            statsReport = null
                            reconnectMessage = null
                            service.startStreaming(endpoint)
                                .onSuccess {
                                    liveState = LiveState.CONNECTING
                                    statusMessage = "Solicitando conexão ao servidor…"
                                }
                                .onFailure {
                                    liveState = LiveState.ERROR
                                    statusMessage = it.message ?: "Não foi possível iniciar a transmissão."
                                }
                        }
                    }
                },
                enabled = liveState !in setOf(LiveState.PREPARING) && ((streamService?.isPrepared == true) || !configSaved),
                modifier = Modifier.fillMaxWidth().height(54.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (liveState == LiveState.LIVE || liveState == LiveState.CONNECTING) Color(0xFFB3261E) else TikTokPink
                ),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text(if (liveState == LiveState.LIVE || liveState == LiveState.CONNECTING) "ENCERRAR TRANSMISSÃO" else "INICIAR TRANSMISSÃO")
            }

            Text(
                statusMessage,
                color = if (liveState == LiveState.ERROR) MaterialTheme.colorScheme.error else Color.Gray,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Text(
                "A captura de tela exige autorização do Android e usa o microfone. Áudio interno ainda pendente.",
                color = Color(0xFFFFC857), style = MaterialTheme.typography.labelSmall
            )
        }

        if (showVideoConfigDialog) {
            AlertDialog(
                onDismissRequest = { showVideoConfigDialog = false },
                title = { Text("Configurações de vídeo e áudio") },
                text = {
                    Column(
                        modifier = Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("As opções são aplicadas ao encoder e salvas neste aparelho. Alterações exigem recriar a prévia e não podem ser feitas durante uma live.", style = MaterialTheme.typography.bodySmall)
                        OutlinedTextField(value = configWidth, onValueChange = { configWidth = it.filter(Char::isDigit) }, label = { Text("Largura (480, 720 ou 1080)") }, singleLine = true)
                        OutlinedTextField(value = configHeight, onValueChange = { configHeight = it.filter(Char::isDigit) }, label = { Text("Altura (854, 1280 ou 1920)") }, singleLine = true)
                        OutlinedTextField(value = configFps, onValueChange = { configFps = it.filter(Char::isDigit) }, label = { Text("FPS (15, 24, 30 ou 60)") }, singleLine = true)
                        OutlinedTextField(value = configVideoKbps, onValueChange = { configVideoKbps = it.filter(Char::isDigit) }, label = { Text("Bitrate de vídeo (kbps, 500–8000)") }, singleLine = true)
                        OutlinedTextField(value = configAudioKbps, onValueChange = { configAudioKbps = it.filter(Char::isDigit) }, label = { Text("Bitrate de áudio (kbps, 64–320)") }, singleLine = true)
                        OutlinedTextField(value = configSampleRate, onValueChange = { configSampleRate = it.filter(Char::isDigit) }, label = { Text("Amostragem (44100 ou 48000 Hz)") }, singleLine = true)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = configStereo, onCheckedChange = { configStereo = it })
                            Text("Áudio estéreo")
                        }
                        videoConfigError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val candidate = runCatching {
                            RtmpStreamEngine.VideoConfig(
                                width = configWidth.toInt(), height = configHeight.toInt(), fps = configFps.toInt(),
                                videoBitrate = configVideoKbps.toInt() * 1000,
                                audioBitrate = configAudioKbps.toInt() * 1000,
                                sampleRate = configSampleRate.toInt(), stereo = configStereo
                            )
                        }.getOrElse {
                            videoConfigError = "Preencha todos os campos com números válidos."
                            return@TextButton
                        }
                        val service = streamService
                        if (service == null) {
                            videoConfigError = "O serviço ainda não está conectado. Tente novamente."
                        } else if (service.isStreaming) {
                            videoConfigError = "Encerre a transmissão antes de alterar o encoder."
                        } else {
                            val validation = runCatching { videoConfigStore.validate(candidate) }
                            if (validation.isFailure) {
                                videoConfigError = validation.exceptionOrNull()?.message ?: "Configuração inválida."
                            } else {
                                val ok = runCatching { service.reconfigure(candidate) }.getOrDefault(false)
                                if (!ok) {
                                    // Recupera a última configuração válida caso o codec rejeite a nova combinação.
                                    val restored = runCatching { service.prepare(videoConfig) }.getOrDefault(false)
                                    if (restored) surfaceView?.let { view -> runCatching { service.startPreview(view) } }
                                    videoConfigError = "O dispositivo não conseguiu preparar o encoder com essas opções. A configuração anterior foi restaurada quando possível."
                                } else {
                                    videoConfigStore.save(candidate)
                                    videoConfig = candidate
                                    surfaceView?.let { view -> runCatching { service.startPreview(view) } }
                                    statusMessage = "Configurações salvas e aplicadas ao encoder."
                                    liveState = LiveState.READY
                                    showVideoConfigDialog = false
                                }
                            }
                        }
                    }) { Text("Salvar e aplicar") }
                },
                dismissButton = { TextButton(onClick = { showVideoConfigDialog = false }) { Text("Cancelar") } }
            )
        }

        if (showOverlayDialog) {
            AlertDialog(
                onDismissRequest = { showOverlayDialog = false },
                title = { Text("Personalizar sobreposição") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("O texto será incorporado ao vídeo enviado para o servidor.", style = MaterialTheme.typography.bodySmall)
                        OutlinedTextField(
                            value = overlayTitle,
                            onValueChange = { overlayTitle = it.take(48) },
                            label = { Text("Título") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = overlaySubtitle,
                            onValueChange = { overlaySubtitle = it.take(72) },
                            label = { Text("Subtítulo") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val service = streamService
                        if (service == null || !service.isPrepared) {
                            statusMessage = "O encoder ainda não está preparado."
                        } else {
                            service.setSceneOverlay(overlayTitle, overlaySubtitle)
                                .onSuccess {
                                    selectedScene = "Personalizada"
                                    statusMessage = "Sobreposição aplicada à prévia e ao vídeo transmitido."
                                    showOverlayDialog = false
                                }
                                .onFailure { statusMessage = it.message ?: "Falha ao aplicar sobreposição." }
                        }
                    }) { Text("Aplicar") }
                },
                dismissButton = {
                    TextButton(onClick = {
                        streamService?.clearSceneOverlay()
                        overlayTitle = ""
                        overlaySubtitle = ""
                        selectedScene = "Sem texto"
                        showOverlayDialog = false
                        statusMessage = "Sobreposição de texto removida."
                    }) { Text("Remover texto") }
                }
            )
        }

        if (showRtmpDialog) {
            AlertDialog(
                onDismissRequest = { showRtmpDialog = false },
                title = { Text("Configuração RTMP") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Informe o endereço base do servidor e a chave fornecida pela plataforma.", style = MaterialTheme.typography.bodySmall)
                        OutlinedTextField(
                            value = serverUrl,
                            onValueChange = { serverUrl = it; validationError = null },
                            label = { Text("URL do servidor (RTMP/RTMPS)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = streamKey,
                            onValueChange = { streamKey = it; validationError = null },
                            label = { Text(if (configSaved && streamKey.isBlank()) "Chave salva (vazio mantém a atual)" else "Chave de transmissão") },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            modifier = Modifier.fillMaxWidth()
                        )
                        validationError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                        Text("A chave é cifrada com AES-GCM e protegida pelo Android Keystore.", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                        Text("Prefira RTMPS: RTMP sem TLS pode expor a chave na rede.", style = MaterialTheme.typography.labelSmall, color = Color(0xFFFFC857))
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val validUrl = serverUrl.trim().startsWith("rtmp://", true) || serverUrl.trim().startsWith("rtmps://", true)
                        if (!validUrl) {
                            validationError = "Use uma URL iniciada por rtmp:// ou rtmps://."
                        } else if (streamKey.isNotBlank()) {
                            runCatching { secureStore.save(serverUrl, streamKey) }
                                .onSuccess {
                                    streamKey = ""
                                    configSaved = true
                                    serverUrl = secureStore.loadServer()
                                    showRtmpDialog = false
                                    validationError = null
                                }
                                .onFailure { validationError = it.message ?: "Falha ao salvar credenciais." }
                        } else if (configSaved && secureStore.hasKey()) {
                            runCatching { secureStore.save(serverUrl, secureStore.readKeyForUpdate()) }
                                .onSuccess {
                                    configSaved = true
                                    showRtmpDialog = false
                                    validationError = null
                                }
                                .onFailure { validationError = it.message ?: "Falha ao atualizar servidor." }
                        } else {
                            validationError = "Informe a chave de transmissão."
                        }
                    }) { Text("Salvar") }
                },
                dismissButton = {
                    Row {
                        if (configSaved) {
                            TextButton(onClick = {
                                secureStore.clear()
                                serverUrl = ""
                                streamKey = ""
                                configSaved = false
                                showRtmpDialog = false
                            }) { Text("Apagar dados") }
                        }
                        TextButton(onClick = { showRtmpDialog = false }) { Text("Cancelar") }
                    }
                }
            )
        }
    }
}

private fun formatDuration(totalSeconds: Long): String {
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return if (hours > 0) "%02d:%02d:%02d".format(hours, minutes, seconds)
    else "%02d:%02d".format(minutes, seconds)
}

@Composable
private fun SceneChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        color = if (selected) TikTokPink.copy(alpha = 0.22f) else StudioPanel,
        shape = RoundedCornerShape(10.dp)
    ) {
        Text(label, Modifier.padding(horizontal = 13.dp, vertical = 10.dp), color = if (selected) TikTokPink else Color.White)
    }
}

@Composable
private fun StudioAction(title: String, state: String, onClick: () -> Unit) {
    TextButton(onClick = onClick, contentPadding = PaddingValues(horizontal = 5.dp, vertical = 7.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, color = Color.White, style = MaterialTheme.typography.labelMedium)
            Text(state, color = TikTokCyan, style = MaterialTheme.typography.labelSmall)
        }
    }
}
