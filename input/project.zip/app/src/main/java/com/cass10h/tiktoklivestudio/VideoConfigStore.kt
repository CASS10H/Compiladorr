package com.cass10h.tiktoklivestudio

import android.content.Context

/** Preferências de codificação persistentes, sem armazenar credenciais RTMP aqui. */
class VideoConfigStore(context: Context) {
    private val prefs = context.getSharedPreferences("video_encoding_config", Context.MODE_PRIVATE)

    fun load(): RtmpStreamEngine.VideoConfig = RtmpStreamEngine.VideoConfig(
        width = prefs.getInt("width", 720),
        height = prefs.getInt("height", 1280),
        videoBitrate = prefs.getInt("video_bitrate", 2_500_000),
        fps = prefs.getInt("fps", 30),
        audioBitrate = prefs.getInt("audio_bitrate", 128_000),
        sampleRate = prefs.getInt("sample_rate", 44_100),
        stereo = prefs.getBoolean("stereo", true)
    )

    fun validate(config: RtmpStreamEngine.VideoConfig) {
        require(config.width to config.height in setOf(480 to 854, 720 to 1280, 1080 to 1920)) {
            "Resolução não suportada. Use 480x854, 720x1280 ou 1080x1920."
        }
        require(config.fps in setOf(15, 24, 30, 60)) { "FPS deve ser 15, 24, 30 ou 60." }
        require(config.videoBitrate in 500_000..8_000_000) { "Bitrate de vídeo deve ficar entre 500 e 8000 kbps." }
        require(config.audioBitrate in 64_000..320_000) { "Bitrate de áudio deve ficar entre 64 e 320 kbps." }
        require(config.sampleRate in setOf(44_100, 48_000)) { "Taxa de amostragem deve ser 44100 ou 48000 Hz." }
    }

    fun save(config: RtmpStreamEngine.VideoConfig) {
        validate(config)
        prefs.edit()
            .putInt("width", config.width).putInt("height", config.height)
            .putInt("video_bitrate", config.videoBitrate).putInt("fps", config.fps)
            .putInt("audio_bitrate", config.audioBitrate).putInt("sample_rate", config.sampleRate)
            .putBoolean("stereo", config.stereo).apply()
    }
}
