package com.cass10h.tiktoklivestudio

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.content.pm.ServiceInfo
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.os.Handler
import android.view.SurfaceView
import androidx.core.app.NotificationCompat
import com.pedro.common.StreamingStatsReport

/**
 * Mantém a sessão RootEncoder fora da Activity. A Activity pode ser destruída
 * enquanto a transmissão continua; ao encerrar a sessão o serviço libera o encoder.
 */
class StreamingForegroundService : Service(), RtmpStreamEngine.Listener {

    interface SessionListener {
        fun onConnecting()
        fun onConnected()
        fun onConnectionFailed(reason: String)
        fun onDisconnected()
        fun onAuthenticationError()
        fun onAuthenticationSuccess()
        fun onNewBitrate(bitrate: Long)
        fun onStats(report: StreamingStatsReport?)
        fun onReconnecting(attempt: Int, maxAttempts: Int, reason: String)
        fun onScreenCaptureStopped(wasStreaming: Boolean)
    }

    companion object {
        const val ACTION_START = "${BuildConfig.APPLICATION_ID}.stream.START"
        const val ACTION_STOP = "${BuildConfig.APPLICATION_ID}.stream.STOP"
        const val ACTION_START_SCREEN = "${BuildConfig.APPLICATION_ID}.stream.START_SCREEN"
        private const val CHANNEL_ID = "live_stream_channel"
        private const val NOTIFICATION_ID = 4103
    }

    inner class LocalBinder : Binder() {
        fun getService(): StreamingForegroundService = this@StreamingForegroundService
    }

    private val binder = LocalBinder()
    private val mainHandler = Handler(Looper.getMainLooper())
    private lateinit var engine: RtmpStreamEngine
    @Volatile private var sessionListener: SessionListener? = null
    @Volatile private var lastBitrate: Long = 0L
    @Volatile private var connected: Boolean = false
    @Volatile private var connectionStartedAt: Long = 0L
    @Volatile private var screenCaptureActive: Boolean = false
    @Volatile private var retryAttempt: Int = 0
    private val maxReconnectAttempts = 3

    val isPrepared: Boolean get() = ::engine.isInitialized && engine.isPrepared
    val isStreaming: Boolean get() = ::engine.isInitialized && engine.isStreaming
    val isConnected: Boolean get() = connected
    val connectedAtElapsedRealtime: Long get() = connectionStartedAt
    val bitrate: Long get() = lastBitrate
    val isScreenCaptureActive: Boolean get() = screenCaptureActive

    override fun onCreate() {
        super.onCreate()
        engine = RtmpStreamEngine(applicationContext, this)
        createNotificationChannel()
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopStreaming()
            ACTION_START_SCREEN -> promoteToForeground(includeMediaProjection = true)
            ACTION_START, null -> promoteToForeground()
        }
        return START_NOT_STICKY
    }

    fun setSessionListener(listener: SessionListener?) {
        sessionListener = listener
    }

    fun prepare(config: RtmpStreamEngine.VideoConfig = RtmpStreamEngine.VideoConfig()): Boolean = engine.prepare(config)

    /** Recria o encoder com novas opções; só é permitido fora de uma transmissão. */
    fun reconfigure(config: RtmpStreamEngine.VideoConfig): Boolean {
        if (isStreaming) return false
        engine.release()
        engine = RtmpStreamEngine(applicationContext, this)
        return engine.prepare(config)
    }

    fun startPreview(surfaceView: SurfaceView) = engine.startPreview(surfaceView)

    fun switchCamera(): Result<Unit> = engine.switchCamera()

    fun setMicrophoneMuted(muted: Boolean): Result<Unit> = engine.setMicrophoneMuted(muted)

    fun setSceneOverlay(title: String, subtitle: String): Result<Unit> = engine.setSceneOverlay(title, subtitle)

    fun clearSceneOverlay(): Result<Unit> = engine.clearSceneOverlay()

    /**
     * Deve ser chamado somente depois do consentimento MediaProjection do sistema.
     * A promoção para FGS com mediaProjection acontece antes de getMediaProjection().
     */
    fun startScreenCapture(resultCode: Int, resultData: Intent): Result<Unit> {
        val result = runCatching {
            require(resultCode == android.app.Activity.RESULT_OK) {
                "A autorização de captura de tela não foi concedida."
            }
            // O FGS com tipo mediaProjection deve existir antes de getMediaProjection().
            promoteToForeground(includeMediaProjection = true)
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val projection = manager.getMediaProjection(resultCode, resultData)
                ?: error("O Android não forneceu uma sessão MediaProjection.")
            engine.startScreenCapture(projection).getOrElse { error ->
                runCatching { projection.stop() }
                throw error
            }
            screenCaptureActive = true
            updateNotification()
        }
        if (result.isFailure) {
            screenCaptureActive = false
            if (isStreaming) {
                promoteToForeground(includeMediaProjection = false)
            } else {
                stopForegroundCompat()
                stopSelf()
            }
        }
        return result
    }

    fun stopScreenCapture(): Result<Unit> = runCatching {
        if (!screenCaptureActive) return@runCatching
        engine.stopScreenCapture().getOrThrow()
        screenCaptureActive = false
        if (isStreaming) {
            promoteToForeground(includeMediaProjection = false)
        } else {
            stopForegroundCompat()
            stopSelf()
        }
    }

    /** Chamado após ação explícita do usuário, enquanto a Activity está visível. */
    fun startStreaming(endpoint: String): Result<Unit> {
        retryAttempt = 0
        promoteToForeground()
        val result = engine.start(endpoint)
        if (result.isFailure) {
            stopProjectionIfActive()
            stopForegroundCompat()
            stopSelf()
        }
        return result
    }

    fun stopStreaming() {
        if (::engine.isInitialized) {
            if (engine.isScreenCaptureActive) runCatching { engine.stopScreenCapture() }
            engine.stop()
        }
        screenCaptureActive = false
        retryAttempt = 0
        mainHandler.removeCallbacksAndMessages(null)
        stopForegroundCompat()
        stopSelf()
    }

    private fun promoteToForeground(includeMediaProjection: Boolean = screenCaptureActive) {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            var types = ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA or
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            if (includeMediaProjection) {
                types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            }
            startForeground(NOTIFICATION_ID, notification, types)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun updateNotification() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification())
    }

    private fun buildNotification(): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            4104,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this,
            4105,
            Intent(this, StreamingForegroundService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setContentTitle("TikTok Live Studio")
            .setContentText(if (screenCaptureActive) "Compartilhando a tela do Android" else "Sessão de transmissão em andamento")
            .setContentIntent(openAppIntent)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(android.R.drawable.ic_media_pause, "Encerrar live", stopIntent)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Transmissão ao vivo",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Controles da transmissão em andamento" }
            manager.createNotificationChannel(channel)
        }
    }

    private fun stopForegroundCompat() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
    }

    private fun dispatch(block: (SessionListener) -> Unit) {
        mainHandler.post { sessionListener?.let(block) }
    }

    override fun onConnecting() {
        connected = false
        connectionStartedAt = 0L
        dispatch { it.onConnecting() }
    }

    override fun onConnected() {
        connected = true
        retryAttempt = 0
        connectionStartedAt = SystemClock.elapsedRealtime()
        dispatch { it.onConnected() }
    }

    private fun stopProjectionIfActive() {
        if (::engine.isInitialized && engine.isScreenCaptureActive) {
            runCatching { engine.stopScreenCapture() }
        }
        screenCaptureActive = false
    }

    override fun onConnectionFailed(reason: String) {
        connected = false
        connectionStartedAt = 0L
        mainHandler.post {
            if (::engine.isInitialized && engine.isStreaming && retryAttempt < maxReconnectAttempts) {
                retryAttempt += 1
                val delayMs = when (retryAttempt) {
                    1 -> 1_000L
                    2 -> 2_000L
                    else -> 4_000L
                }
                sessionListener?.onReconnecting(retryAttempt, maxReconnectAttempts, reason)
                val accepted = engine.retryConnection(delayMs, reason)
                if (!accepted) finishFailedConnection(reason)
            } else {
                finishFailedConnection(reason)
            }
        }
    }

    private fun finishFailedConnection(reason: String) {
        stopProjectionIfActive()
        if (::engine.isInitialized && engine.isStreaming) engine.stop()
        stopForegroundCompat()
        stopSelf()
        sessionListener?.onConnectionFailed(reason)
    }

    override fun onDisconnected() {
        connected = false
        connectionStartedAt = 0L
        mainHandler.post {
            retryAttempt = 0
            if (!isStreaming) {
                stopProjectionIfActive()
                stopForegroundCompat()
                stopSelf()
            }
            sessionListener?.onDisconnected()
        }
    }

    override fun onAuthenticationError() {
        connected = false
        connectionStartedAt = 0L
        mainHandler.post {
            stopProjectionIfActive()
            if (::engine.isInitialized && engine.isStreaming) engine.stop()
            stopForegroundCompat()
            stopSelf()
            sessionListener?.onAuthenticationError()
        }
    }

    override fun onScreenProjectionStopped() {
        mainHandler.post {
            val wasStreaming = ::engine.isInitialized && engine.isStreaming
            screenCaptureActive = false
            if (::engine.isInitialized) {
                engine.handleProjectionStoppedBySystem()
                if (engine.isStreaming) engine.stop()
            }
            stopForegroundCompat()
            stopSelf()
            sessionListener?.onScreenCaptureStopped(wasStreaming)
        }
    }

    override fun onAuthenticationSuccess() = dispatch { it.onAuthenticationSuccess() }

    override fun onNewBitrate(bitrate: Long) {
        lastBitrate = bitrate
        dispatch { it.onNewBitrate(bitrate) }
    }

    override fun onStats(report: StreamingStatsReport?) = dispatch { it.onStats(report) }

    override fun onDestroy() {
        sessionListener = null
        if (::engine.isInitialized) engine.release()
        stopForegroundCompat()
        super.onDestroy()
    }
}
